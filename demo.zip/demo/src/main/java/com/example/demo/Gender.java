package com.example.demo;

public enum Gender {
    MALE,FEMALE
}
